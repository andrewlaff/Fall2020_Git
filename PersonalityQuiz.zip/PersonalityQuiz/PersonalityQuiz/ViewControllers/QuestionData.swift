//
//  QuestionData.swift
//  PersonalityQuiz
//
//  Created by Andrew Lafferty on 11/1/20.
//

import Foundation

struct Question {
    var text: String
    var type: ResponseType
    var answers : [Answer]
}

enum ResponseType {
    case single, multiple, range
}

struct Answer {
    var text: String
    var type: Destination
}

enum Destination: Character {
    case newYork = "🗽", vegas = "🎲", keyWest = "🏝", jacksonHole = "🏔"

    var definition: String {
        switch self {
        case .newYork:
            return "It's clear that you need to visit New York City.  The city that never sleep.  With so much to do here, you're guaranteed to never get bored."
        case .vegas:
            return "LAS VEGAS!!!  There's no doubt, Sin City is your next stop.  Entertainment, Gambling, and Food all at your finger tips, you're guaranteed a fun time."
        case .keyWest:
            return "The sun will soon be shining down on you in Key West.  With the perfect mix of relaxation and adventure, you're guaranteed to enjoy this tropical paradise."
        case .jacksonHole:
            return "Get stoked for Jackson Hole.  Whether it's skiing, grizzlies, 10K foot peaks, this place is guaranteed to stratch all of your adventurous itches."
        }
    }
}


