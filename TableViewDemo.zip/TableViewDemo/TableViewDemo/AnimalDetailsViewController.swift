//
//  AnimalDetailsViewController.swift
//  TableViewDemo
//
//  Created by Andrew Lafferty on 11/5/20.
//

import UIKit

class AnimalDetailsViewController: UIViewController {

    var animal: Animal?
    
    @IBOutlet var pictureLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var areaLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let animal = animal {
            pictureLabel.text = animal.picture
            nameLabel.text = animal.name
            areaLabel.text = animal.area
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
