//
//  CustomAnimalCellTableViewCell.swift
//  TableViewDemo
//
//  Created by Andrew Lafferty on 11/5/20.
//

import UIKit

class CustomAnimalCell: UITableViewCell {
    
    @IBOutlet var pictureLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var areaLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
