//
//  ViewController.swift
//  Apple Pie
//
//  Created by Andrew Lafferty on 10/10/20.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newRound()
    }
    
    @IBOutlet var treeImageView: UIImageView!
    @IBOutlet var correctWordLabel: UILabel!
    @IBOutlet var scoreLabel: UILabel!
    @IBOutlet var letterButtons: [UIButton]!
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        sender.isEnabled = false
//        need better understanding of next two constants
        let letterString = sender.title(for: .normal)!
        let letter = Character(letterString.lowercased())
        currentGame.playerGuess(letter: letter)
        updatedGameState()
    }
  
    var listOfWords = ["pizza", "coding", "bears", "baseball", "bitcoin"]
    
    let incorrectMovesAllowed = 7
    
    var totalWins = 0 {
        didSet {
            newRound()
        }
    }
    
    var totalLoses = 0 {
        didSet {
            newRound()
        }
    }
    
    var currentGame: Game!
    
    func newRound() {
        if !listOfWords.isEmpty {
            let newWord = listOfWords.removeFirst()
            currentGame = Game(word: newWord, incorrectMovesRemaining: incorrectMovesAllowed, guessedLetters: [])
            enableLetterButtons(true)
            updateUI()
        } else {
            enableLetterButtons(false)
        }
    }
    
    func enableLetterButtons(_ enable: Bool) {
//        underscore ????
        for button in letterButtons {
            button.isEnabled = enable
        }
    }
    
    func updatedGameState() {
        if currentGame.incorrectMovesRemaining == 0 {
            totalLoses += 1
        } else if currentGame.word == currentGame.formattedWord {
           totalWins += 1
        } else {
            updateUI()
        }
    }

    func updateUI() {
        var letters: [String] = []
        for letter in currentGame.formattedWord {
            letters.append(String(letter))
        }
        
        let wordsWithSpacing = letters.joined(separator: " ")
        
        correctWordLabel.text = wordsWithSpacing
        scoreLabel.text = "Wins: \(totalWins), Losses: \(totalLoses)"
        treeImageView.image = UIImage (named: "Tree \(currentGame.incorrectMovesRemaining)")
    }
}

